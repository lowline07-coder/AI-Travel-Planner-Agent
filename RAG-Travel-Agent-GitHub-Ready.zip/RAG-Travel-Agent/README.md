# 🌍 AI Travel Planner Agent

An AI-powered travel planning application built with Python, Streamlit, LangChain and Groq. The application generates a personalized travel plan based on the destination, budget, number of days and travel type.

## ✨ Features

- Destination overview
- Tourist attractions
- Hotel recommendations
- Restaurant recommendations
- Day-wise itinerary
- Budget planning
- Packing list
- Travel tips

## 🛠️ Tech Stack

- Python
- Streamlit
- LangChain
- LangChain-Groq
- Groq LLM
- Llama 3.3 70B
- python-dotenv

## 📁 Project Structure

```text
RAG-Travel-Agent/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── screenshots/
    └── demo.png
```

## 🚀 Setup

### 1. Clone the repository

```bash
git clone <your-github-repository-url>
cd RAG-Travel-Agent
```

### 2. Create a virtual environment

```bash
python -m venv env
```

Activate it on Windows:

```bash
env\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure the API key

Create a `.env` file in the project root based on `.env.example`:

```env
GROQ_API_KEY=your_groq_api_key_here
```

Never commit `.env` or real API keys to GitHub.

### 5. Run the application

```bash
streamlit run app.py
```

## 🧠 How It Works

1. The user enters a destination.
2. The user specifies a travel budget.
3. The user selects the number of days.
4. The user selects the travel type.
5. The application sends these requirements to the Groq-powered LLM.
6. The generated travel plan is displayed in the Streamlit interface.

## 📌 Example Inputs

- Destination: Jaipur
- Budget: ₹15,000
- Duration: 3 days
- Travel Type: Solo

## 🔐 Security

API credentials are loaded through environment variables. Real credentials are intentionally excluded from this repository.
