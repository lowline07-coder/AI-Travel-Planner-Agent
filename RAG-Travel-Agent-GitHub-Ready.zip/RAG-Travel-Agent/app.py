import os
import streamlit as st
from dotenv import load_dotenv
from langchain_groq import ChatGroq

load_dotenv()

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    api_key=os.getenv("GROQ_API_KEY"),
    temperature=0.3
)

def travel_agent(city, budget, days, travel_type):

    prompt = f"""
    Plan a trip for:

    City: {city}
    Budget: ₹{budget}
    Days: {days}
    Travel Type: {travel_type}

    Include:
    - Destination Overview
    - Attractions
    - Hotels
    - Restaurants
    - Day-wise itinerary
    - Budget
    - Packing List
    - Travel Tips
    """

    response = llm.invoke(prompt)

    return response.content


# -----------------------------
# Streamlit starts here
# -----------------------------

st.set_page_config(page_title="AI Travel Planner")

st.title("🌍 AI Travel Planner")

city = st.text_input("Destination", "Jaipur")
budget = st.number_input("Budget", value=15000)
days = st.number_input("Days", value=3)
travel_type = st.selectbox(
    "Travel Type",
    ["Solo", "Couple", "Family", "Friends", "Business"]
)

if st.button("Plan My Trip"):

    with st.spinner("Planning your trip..."):

        result = travel_agent(
            city,
            budget,
            days,
            travel_type
        )

        st.markdown(result)